$(function(){
    getHt();
    initMap();
});

//获取div的高度
function getHt(){
   var all_height = $(window).height();
   var div_height = all_height - 84;  // Adjust the height calculation as needed
   $("#car_control").css("height", div_height + "px");
}

//加载地图
function initMap(){
    // 百度地图API功能
    var map = new BMap.Map("map");    // 创建Map实例

    // 设置南京的地图中心点和缩放级别
    map.centerAndZoom(new BMap.Point(118.796877, 32.060255), 12);  // 南京

    //添加地图类型控件
    var size1 = new BMap.Size(10, 50);
    map.addControl(new BMap.MapTypeControl({
        offset: size1,
        mapTypes:[
            BMAP_NORMAL_MAP,
            BMAP_HYBRID_MAP,
        ]
    }));

    // 编写自定义函数,创建标注
    function addMarker(point){
        var marker = new BMap.Marker(point);
        map.addOverlay(marker);
    }

    // 直接添加南京市区内的标注点
    var points = [
        new BMap.Point(118.796877, 32.060255),  // 南京市中心
        new BMap.Point(118.811717, 32.02466),   // 新街口
        new BMap.Point(118.813938, 32.028169),  // 夫子庙
        new BMap.Point(118.745364, 32.056589)   // 南京大学
    ];

    points.forEach(function(point) {
        addMarker(point);
    });

    map.setCurrentCity("南京");  // 设置地图显示的城市
    map.enableScrollWheelZoom(true);  //开启鼠标滚轮缩放

    //加载城市控件
    var size = new BMap.Size(10, 50);
    map.addControl(new BMap.CityListControl({
        anchor: BMAP_ANCHOR_TOP_LEFT,
        offset: size,
    }));
}

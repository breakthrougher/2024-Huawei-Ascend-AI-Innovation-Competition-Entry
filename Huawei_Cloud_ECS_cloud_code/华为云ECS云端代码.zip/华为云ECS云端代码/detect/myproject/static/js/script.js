document.addEventListener("DOMContentLoaded", function () {
    const container = document.querySelector(".toast-container");

    // 定义 Toast 类型及内容
    const TOAST_TYPE_STUFF = {
        ai: {
            icon: `
                <svg id="warning" xmlns="http://www.w3.org/2000/svg" width="800" height="800" fill="none" viewBox="0 0 24 24">
					<path d="M1.333 8.074a1 1 0 1 0 1.334 1.49l-1.334-1.49Zm20 1.49a1 1 0 1 0 1.334-1.49l-1.334 1.49ZM12 19a1 1 0 1 0 0 2v-2Zm.01 2a1 1 0 1 0 0-2v2Zm2.68-3.96a1 1 0 0 0 1.346-1.48l-1.346 1.48Zm3.364-3.7a1 1 0 0 0 1.346-1.48l-1.346 1.48Zm-10.09 2.22a1 1 0 0 0 1.345 1.48l-1.345-1.48ZM4.6 11.86a1 1 0 1 0 1.346 1.48L4.6 11.86Zm5.97-7.797a1 1 0 0 0 .177 1.992l-.177-1.992Zm6.77 6.317a1 1 0 1 0-.973 1.748l.972-1.748ZM3.706 2.293a1 1 0 0 0-1.414 1.414l1.414-1.414Zm16.586 19.414a1 1 0 0 0 1.414-1.414l-1.414 1.414ZM12 6c3.586 0 6.856 1.347 9.333 3.565l1.334-1.49A15.944 15.944 0 0 0 12 4v2Zm0 15h.01v-2H12v2Zm0-5c1.037 0 1.98.393 2.69 1.04l1.346-1.48A5.982 5.982 0 0 0 12 14v2Zm-2.69 1.04A3.982 3.982 0 0 1 12 16v-2a5.982 5.982 0 0 0-4.036 1.56l1.345 1.48Zm1.437-10.985C11.16 6.02 11.577 6 12 6V4c-.482 0-.958.021-1.43.063l.177 1.992Zm5.62 6.073a9.031 9.031 0 0 1 1.687 1.212l1.346-1.48a11.03 11.03 0 0 0-2.06-1.48l-.973 1.748ZM2.293 3.708 5.466 6.88l1.415-1.415-3.174-3.173-1.414 1.414Zm.374 5.857a14.01 14.01 0 0 1 3.895-2.47l-.777-1.843a16.01 16.01 0 0 0-4.452 2.822l1.334 1.49Zm2.8-2.684 3.993 3.994 1.415-1.415L6.88 5.466 5.466 6.881Zm3.993 3.994 10.833 10.832 1.414-1.414L10.875 9.46 9.46 10.875ZM5.946 13.34a8.97 8.97 0 0 1 4.404-2.19l-.365-1.966A10.97 10.97 0 0 0 4.6 11.861l1.346 1.48Z"></path>
				</svg>
            `,
            text: "AI action detected!"
        }
    };

    // 获取 Toast 的 HTML
    function getToastHtml(type) {
        const { icon, text } = TOAST_TYPE_STUFF[type];
        return `
            <div class="toast" data-type="${type}">
                <div class="toast_inner">
                    <div class="toast_icon">
                        ${icon}
                    </div>
                    <div class="toast_text"> 
                        ${text}
                    </div>
                </div>
            </div>
        `;
    }

    // 显示 Toast 弹窗
    function showToast() {
        const toastHtml = getToastHtml("ai");
        container.insertAdjacentHTML("beforeend", toastHtml);

        // 3 秒后自动关闭弹窗
        const toast = container.lastElementChild;
        setTimeout(() => {
            toast.classList.add("toast_out");
            setTimeout(() => toast.remove(), 250); // 完成动画后移除元素
        }, 30000); // 显示 3 秒
    }

    // 检查文件夹变化
    function checkForChanges() {
        fetch('/api/get-latest-error/')
            .then(response => response.json())
            .then(data => {
                if (data.device1_count !== previousDevice1Count || data.device2_count !== previousDevice2Count) {
                    showToast();  // 仅输出 AI 弹窗
                    previousDevice1Count = data.device1_count;
                    previousDevice2Count = data.device2_count;
                }
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    // 每 3 秒检查一次图片数量变化
    setInterval(checkForChanges, 3000); // 3 秒更新一次
});

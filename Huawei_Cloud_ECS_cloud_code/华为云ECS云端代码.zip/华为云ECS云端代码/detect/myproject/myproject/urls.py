"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from detect.views import index, car_control,get_chart_data, get_device_data,get_chart_series_data,get_anomaly_data,get_alerts
from detect.views import get_latest_data,get_error_data,car,get_latest_error
 

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index, name='index'),
    path('api/get-chart-data/', get_chart_data, name='get_chart_data'),
    path('api/get-device-data/', get_device_data, name='get_device_data'),
    path('api/get-anomaly-data/', get_anomaly_data, name='get_anomaly_data'),
    path('api/get-alerts/', get_alerts, name='get_alerts'),
    path('api/get-chart-series-data/', get_chart_series_data, name='get_chart_series_data'),
    path('api/get-latest-data/', get_latest_data, name='get_latest_data'),
    path('car-control/', car_control, name='car_control'),
    path('car/', car, name='car'),
    path('api/get-latest-error/', get_latest_error, name='get_latest_error'),
    path('get_error_data/', get_error_data, name='get_error_data'),
]
